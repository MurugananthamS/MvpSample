package com.murugan.mvcsample.ui.base;

import android.support.annotation.StringRes;



public interface IBaseView {

    BaseActivity getBaseActivity();

    void initUI();

    void showLoading();

    void hideLoading();

    void onError(@StringRes int resId);

    void onError(String message);

    void showMessage(String message);

    void showMessage(@StringRes int resId);

    boolean isNetworkConnected();

    void hideKeyboard();

    int getStatusBarHeight();

    void showAlertWithPositiveButton(int style, String msg);



}
