package com.murugan.mvcsample.ui.base;

import android.app.Activity;


public interface IBasePresenter<V extends IBaseView> {

    void onAttach(V mvpView);

    void onDetach();

    int getDeviceHeight(Activity activity);

}
