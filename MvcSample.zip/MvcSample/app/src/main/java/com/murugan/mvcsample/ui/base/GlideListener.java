package com.murugan.mvcsample.ui.base;

import android.graphics.drawable.Drawable;

/**
 * Created on 28-Mar-18.
 */

public interface GlideListener {
    void onImageLoaded(Drawable resource);
    void onImageFailed();
}
