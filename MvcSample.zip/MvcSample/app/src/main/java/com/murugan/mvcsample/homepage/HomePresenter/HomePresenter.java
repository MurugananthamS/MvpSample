package com.murugan.mvcsample.homepage.HomePresenter;

import android.content.Context;

import com.murugan.mvcsample.homedata.HomeLogin;
import com.murugan.mvcsample.homepage.HomeConstructor.Homecontractor;
import com.murugan.mvcsample.ui.base.BasePresenter;

public class HomePresenter <V extends Homecontractor.IVhome> extends BasePresenter<V> implements Homecontractor.IPHome<V> {
private HomeLogin homeLogin;


public HomePresenter(Context cxt){
    homeLogin= new HomeLogin(cxt);
}
    @Override
    public boolean Validation(String UserName,String passWord) {

        return homeLogin.LoginValidation(UserName,passWord);
    }
}
