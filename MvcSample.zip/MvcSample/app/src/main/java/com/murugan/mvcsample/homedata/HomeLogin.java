package com.murugan.mvcsample.homedata;

import android.content.Context;
import android.widget.Toast;

public class HomeLogin {
    Context cxt;
    public HomeLogin(Context cxt){
        this.cxt=cxt;

    }


    public boolean LoginValidation(String userName,String passWord){

        if(userName.length()>5 && passWord.length()>6){
            return true;
        }else{
            return false;
        }

    }

}
