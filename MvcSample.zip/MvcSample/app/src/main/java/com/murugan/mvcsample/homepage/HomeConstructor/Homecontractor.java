package com.murugan.mvcsample.homepage.HomeConstructor;

import com.murugan.mvcsample.ui.base.IBasePresenter;
import com.murugan.mvcsample.ui.base.IBaseView;

public interface Homecontractor {


    interface IVhome extends IBaseView{

    }
    interface  IPHome<V extends  IVhome> extends IBasePresenter<V>{
         boolean Validation(String UserName, String passWord);

    }
}
