package com.murugan.mvcsample.homepage;

import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.murugan.mvcsample.R;
import com.murugan.mvcsample.databinding.ActivityMainBinding;
import com.murugan.mvcsample.homepage.HomeConstructor.Homecontractor;
import com.murugan.mvcsample.homepage.HomePresenter.HomePresenter;
import com.murugan.mvcsample.ui.base.BaseActivity;

public class MainActivity extends BaseActivity implements Homecontractor.IVhome,View.OnClickListener {
    ActivityMainBinding binding;
Homecontractor.IPHome<Homecontractor.IVhome> ipHome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        binding.getRoot().requestFocus();
        initialize();
    }

    private void initialize() {
        ipHome=new HomePresenter<>(this);
        binding.tvHome.setOnClickListener(this);
        binding.loginlayout.button.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button:
                try{
                String userName=binding.loginlayout.username.getText().toString();
                String password=binding.loginlayout.password.getText().toString();
               Boolean yesNo= ipHome.Validation(userName,password);
               if(yesNo){
                   Toast.makeText(this,"successfully Login",Toast.LENGTH_LONG).show();

               }else{
                   Toast.makeText(this,"login Failed",Toast.LENGTH_LONG).show();

               }


        }catch (Exception e){
                    e.printStackTrace();
                }
                break;
    }}

    @Override
    public BaseActivity getBaseActivity() {
        return null;
    }

    @Override
    public void initUI() {

    }

    @Override
    public void showLoading() {

    }

    @Override
    public void hideLoading() {

    }

    @Override
    public void onError(int resId) {

    }

    @Override
    public void onError(String message) {

    }

    @Override
    public void showMessage(String message) {

    }

    @Override
    public void showMessage(int resId) {

    }

    @Override
    public boolean isNetworkConnected() {
        return false;
    }

    @Override
    public void hideKeyboard() {

    }

    @Override
    public int getStatusBarHeight() {
        return 0;
    }

    @Override
    public void showAlertWithPositiveButton(int style, String msg) {

    }
}
